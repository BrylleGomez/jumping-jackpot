import java.io.IOException;

public interface Observer {

	public void process_message(msg m) throws IOException;
	
}
