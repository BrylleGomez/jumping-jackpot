import java.io.IOException;

public class SlowSpeed implements Speed {

	public void speed(ProxyLED proxyled)
	{
		try {
			proxyled.send_msg(new msg((byte)(1)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
