import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ProxyLED extends Proxy{

	Speed speed;
	
	ProxyLED(String name, int id, InputStream in, OutputStream out, Dispatcher d, Game g) throws IOException {
		super(name, id, in, out, d, g);
		// TODO Auto-generated constructor stub
	}
	
	public void setSpeed(Speed sp)
	{
		this.speed = sp;
	}
	
	public void performSpeed()
	{
		speed.speed(this);
	}
	
	public void process_message(msg m) throws IOException {
		
		if (m.getId() == id) {
			
			byte payload = m.getPayload();
		    Debug.trace(this.name+": Message "+payload+" received from dispatcher");
		    switch(payload) {
		   	case 1:
		    	g.bottomLED1();
		    	break;
		    case 2:
		    	g.bottomLED2();
		    	break;    	
		    default:
		    	;
		    }	
			
		}
		       
	}	
}
