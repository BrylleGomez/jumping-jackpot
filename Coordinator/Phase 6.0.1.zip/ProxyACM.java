import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ProxyACM extends Proxy {
	
	ProxyACM(String name, int id, InputStream in, OutputStream out, Dispatcher d, Game g) throws IOException {
		super(name, id, in, out, d, g);
		// TODO Auto-generated constructor stub
	}
	
	public void process_message(msg m) throws IOException {
		
		if (m.getId() == id) {
			
			byte payload = m.getPayload();
		    Debug.trace(this.name+": Message "+payload+" received from dispatcher");
		    switch(payload) {
		    case 1:
		    	g.jumped();
		    	break;
		    case 2:
		    	g.landed();
		    	break;
		    default:
		    	;
		    }
			
		}
		
		
    }	       
}

