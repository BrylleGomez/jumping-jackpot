import java.io.IOException;

public class EasyGame extends Game implements Runnable{
	
	// Non-common method of Template pattern for Game class
	void setspeed(ProxyLED p) throws IOException
	{
		p.setSpeed(new SlowSpeed());
		p.performSpeed();
		
		Debug.trace("LED speed set to SLOW");
	}
}
