
public interface Speed {
	
	public void speed(ProxyLED proxyLED);

}
