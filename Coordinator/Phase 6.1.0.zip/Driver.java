import java.io.IOException;

public class Driver {

	public static void main(String[] args) throws IOException, InterruptedException {
			
		Game g = new Game();
		Thread t = new Thread(g);
		t.start();
		//t.wait();
	
		/*
		// Creating two pipes, one outbound(1) and one inbound(2) 
		// Outbound
		PipedOutputStream pos1 = new PipedOutputStream();
		PipedInputStream pis1 = new PipedInputStream(pos1);
		DataOutputStream dos1 = new DataOutputStream(pos1);
		DataInputStream dis1 = new DataInputStream(pis1);
		// Inbound
		PipedOutputStream pos2 = new PipedOutputStream();
		PipedInputStream pis2 = new PipedInputStream(pos2);
		DataOutputStream dos2 = new DataOutputStream(pos2);
		DataInputStream dis2 = new DataInputStream(pis2);
		*/
			
	}
	
	
	
}
