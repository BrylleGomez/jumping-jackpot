import java.io.IOException;

public class Game implements Runnable{
	
	int score = 0;
	
	boolean scored = false;
	boolean jumped = false;
	boolean bottomLED = false;
	
	void jumped() throws IOException { //called by acm proxy
		jumped = true;
	}
	
	void landed() throws IOException { //called by acm proxy
		jumped = false;
	}
	
	void bottomLED1() throws IOException { //called by led proxy
		bottomLED = true;
	}
	
	void bottomLED2() throws IOException { //called by led proxy
		bottomLED = false;
	}		
	
	@Override
	public void run() {
		
		try { // try block catches any exception
			
			Debug.tracefile("debugtrace.txt"); // Save console messages to a file (located in project directory)
			
			// Announce ED numbers
			Debug.trace("LED is ED0!");
			Debug.trace("ACM is ED1!");
			
			SerialPortHandle sph = new SerialPortHandle("COM9"); 							// Initiate serial port for MS Windows
			////SerialPortHandle sph = new SerialPortHandle("/dev/tty.usbserial-A601ERES"); // Initiate serial port for Mac OS
			Dispatcher d = new Dispatcher(sph); // Create a dispatcher
			
			// Create and start proxy objects
			ProxyLED led_proxy = new ProxyLED("led_proxy", 0, System.in, System.out, d, this); // Proxy object for the LED strip (end device 0)
			ProxyACM acm_proxy = new ProxyACM("acm_proxy", 1, System.in, System.out, d, this); // Proxy object for the accelerometer (end device 1)
			
			//Debug.trace("Score = " + this.score + " jumped = " + this.jumped + " bottomLED = " + this.bottomLED);
			
			/*
			// Send decoy messages to end devices
			led_proxy.send_msg(new msg((byte)23)); //send instruction 23 to LED
			acm_proxy.send_msg(new msg((byte)63)); //send instruction 63 to ACM
			*/			
			
			led_proxy.send_msg(new msg((byte)2)); //send instruction 23 to LED (id 0)
			
			led_proxy.setSpeed(new SlowSpeed());
			
			while(true) {
				if (System.in.available() > 0) {
					int x = (int)System.in.read() - 48;
					Debug.trace("Input: " + x);
					switch(x) {
					case 1:
						led_proxy.setSpeed(new SlowSpeed());
						Debug.trace("LED speed set to SLOW");
						break;
					case 2:
						led_proxy.setSpeed(new FastSpeed());
						Debug.trace("LED speed set to FAST");
						break;
					default:
						;
					}
				}
				
				if (this.bottomLED && this.jumped) {
					score += 10;
					System.out.println("You scored! Score = " + score);
					scored = true;
					this.bottomLED = false;
					this.jumped = false;
				}
				
			}
			
		} catch (Exception e) { // terminate the program if exception is caught
			e.printStackTrace();
			System.exit(1);
		}
		
	}

}

