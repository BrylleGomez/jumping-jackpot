import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class Proxy implements Runnable, Observer {
	
	String name;
	int id;
	//InputStream in;
	//OutputStream out; 
	Dispatcher d;
	Game g;
	
	// Proxy object constructor
	Proxy(String name, int id, InputStream in, OutputStream out, Dispatcher d, Game g) throws IOException{
		
		// initialize data members
		this.name = name;
		this.id = id;
		//this.in = new BufferedInputStream(in);
		//this.out = new BufferedOutputStream(out);
		this.d = d;
		this.g = g;
		
		d.register(this); 										// register yourself as a proxy with dispatcher d
		
		new Thread(this).start(); 								// start the thread
		
	}
	
	// This is how the proxy passes messages to the dispatcher
	void send_msg(msg m) throws IOException {
		Debug.trace(this.name+": Sending "+m.getPayload()+" to the dispatcher");
		d.send_msg(this, m); 									// send to the dispatcher a pointer to the sending proxy object along with the message
	}
 
	// This is how the proxy receives messages from the dispatcher
	// This is the callback function that the dispatcher calls
	abstract public void process_message(msg m) throws IOException;
	
	// Proxy run method
	public void run() {		
		/*
		try { 													// try block that catches any exception
			byte b; 
			while(true) {										// the run method simply reads data from the input stream (System.in in this case),
																// if there is, and passes it to the dispatcher
				if(in.available()>0) {							// check if there is data waiting to be read from the input stream
					b = (byte) in.read();						// read a byte from the input stream (System.in in this case)
					Debug.trace(this.name+": Sending "+b+" to the dispatcher");
					d.send_msg(this,new msg(b));				// pass message to the dispatcher
					
				}
			}
		} catch (Exception e) { 								//if any exception is caught, terminate program
			e.printStackTrace();
			System.exit(1);
		}	
		*/		
		while(true);
		
	} //end run method

}