import java.io.IOException;

public class Game implements Runnable {
	
	// Attributes
	int score = 0;							// keeps track of the score
	boolean jumped = false;					// keeps track of whether player is in mid-air
	boolean bottomLED = false;				// keeps track of whether LEDs are in the area to be jumped over
	
	void jumped() throws IOException { 		//called by acm proxy
		jumped = true;
	}
	
	void landed() throws IOException { 		//called by acm proxy
		jumped = false;
	}
	
	void bottomLED1() throws IOException { 	//called by led proxy
		bottomLED = true;
	}
	
	void bottomLED2() throws IOException { 	//called by led proxy
		bottomLED = false;
	}		
	
	@Override
	public void run() {
		
		try { // try block catches any exception
			
			Debug.tracefile("debugtrace.txt"); // Save console messages to a file (located in project directory)
			
			// Announce ED numbers
			Debug.trace("LED is ED0!");
			Debug.trace("ACM is ED1!");
			
			SerialPortHandle sph = new SerialPortHandle("COMz"); 							// Initiate serial port for MS Windows
			////SerialPortHandle sph = new SerialPortHandle("/dev/tty.usbserial-A601ERES"); // Initiate serial port for Mac OS
			Dispatcher d = new Dispatcher(sph); // Create a dispatcher
			
			// Create and start proxy objects
			ProxyLED led_proxy = new ProxyLED("led_proxy", 0, System.in, System.out, d, this); // Proxy object for the LED strip (end device 0)
			ProxyACM acm_proxy = new ProxyACM("acm_proxy", 1, System.in, System.out, d, this); // Proxy object for the accelerometer (end device 1)
			
			//led_proxy.send_msg(new msg((byte)2)); //send instruction 23 to LED (id 0)
			
			//led_proxy.setSpeed(new SlowSpeed());
			
			while(true) {
				if (System.in.available() > 0) {
					int x = (int)System.in.read();
					if (x != 10 && x != 13) {		// discard newline and carriage return bytes
						x -= 48;					// convert from ASCII
						Debug.trace("Input: " + x);
						switch(x) {
						case 1:
							led_proxy.setSpeed(new SlowSpeed());
							led_proxy.performSpeed();
							Debug.trace("LED speed set to SLOW");
							break;
						case 2:
							led_proxy.setSpeed(new FastSpeed());
							led_proxy.performSpeed();
							Debug.trace("LED speed set to FAST");
							break;
						default:
							;
						}	
					}
				}
				
				if (this.bottomLED && this.jumped) {	// check if these two conditions are met
					score += 10;						// increment score 
					System.out.println("You scored! Score = " + score);
					this.bottomLED = false;				// reset flag
					this.jumped = false;				// reset flag
				}
				
			}
			
		} catch (Exception e) { // terminate the program if exception is caught
			e.printStackTrace();
			System.exit(1);
		}
		
	}

}

