import java.io.IOException;

public class HardGame extends Game implements Runnable{
	
	// Non-common method of Template pattern for Game class
	void setspeed(ProxyLED p) throws IOException
	{
		p.setSpeed(new FastSpeed());
		p.performSpeed();
		
		Debug.trace("LED speed set to SLOW");
	}
}