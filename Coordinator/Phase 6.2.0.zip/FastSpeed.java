import java.io.IOException;

public class FastSpeed implements SpeedBehavior {

	public void speed(ProxyLED proxyled)
	{
		try {
			for (int i = 0; i < 3; i++) {					// send instruction 3 times to increase chances of being received correctly
				proxyled.send_msg(new msg((byte)(2)));		// send instruction 6 to LED
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
