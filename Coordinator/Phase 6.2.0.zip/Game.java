import java.io.IOException;

public abstract class Game implements Runnable {
	
	// Attributes
	int score = 0;							// keeps track of the score
	boolean jumped = false;					// keeps track of whether player is in mid-air
	boolean bottomLED = false;				// keeps track of whether LEDs are in the area to be jumped over
	boolean stop = false;
	
	// Call-back Methods
	void jumped() throws IOException { 		// called by acm proxy
		jumped = true;
	}
	void landed() throws IOException { 		// called by acm proxy
		jumped = false;
	}
	void bottomLED1() throws IOException { 	// called by led proxy
		bottomLED = true;
	}
	void bottomLED2() throws IOException { 	// called by led proxy
		bottomLED = false;
	}		
	void stop() throws IOException {		// called by led proxy
		stop = true;
	}
	
	// Other Methods
	void start(ProxyLED p) throws IOException {	// signal led proxy to start game
		p.send_msg(new msg((byte) 4));
	}
	void flashLED3(ProxyLED p) throws IOException {	// signal led proxy to flash LED lights 3 times
		p.send_msg(new msg((byte) 3));
	}
	abstract void setspeed(ProxyLED p) throws IOException; // non-common method of Template pattern
	
	@Override
	public void run() {	// recipe for template pattern (inherited by EasyGame and HardGame)
		
		try { // try block catches any exception
			
			Debug.tracefile("debugtrace.txt"); // Save console messages to a file (located in project directory)
			
			// Announce ED numbers
			Debug.trace("LED is ED0!");
			Debug.trace("ACM is ED1!");
			
			SerialPortHandle sph = new SerialPortHandle("COM9"); 							// Initiate serial port for MS Windows
			////SerialPortHandle sph = new SerialPortHandle("/dev/tty.usbserial-A601ERES"); // Initiate serial port for Mac OS
			Dispatcher d = new Dispatcher(sph); // Create a dispatcher
			
			// Create and start proxy objects
			ProxyLED led_proxy = new ProxyLED("led_proxy", 0, System.in, System.out, d, this); // Proxy object for the LED strip (end device 0)
			ProxyACM acm_proxy = new ProxyACM("acm_proxy", 1, System.in, System.out, d, this); // Proxy object for the accelerometer (end device 1)
			
			this.flashLED3(led_proxy);		// make LED flash 3 times to indicate game start
			this.setspeed(led_proxy);		// set initial LED speed; non-common recipe of template pattern
			this.start(led_proxy);			// start LED light sequence
			
			//led_proxy.send_msg(new msg((byte)2)); //send instruction 23 to LED (id 0)
			//led_proxy.setSpeed(new SlowSpeed());
			
			while(true) {
				
				// Game Over
				if (stop) {
					System.out.println("Game Over! Final score = " + score);
					break;
				}
				
				// Waits for 0 or 1 input from System.in to set speed to slow or fast
				if (System.in.available() > 0) {
					int x = (int)System.in.read();
					if (x != 10 && x != 13) {		// discard newline and carriage return bytes
						x -= 48;					// convert from ASCII
						Debug.trace("Input: " + x);
						switch(x) {
						case 1:
							led_proxy.setSpeed(new SlowSpeed());
							led_proxy.performSpeed();
							Debug.trace("LED speed set to SLOW");
							break;
						case 2:
							led_proxy.setSpeed(new FastSpeed());
							led_proxy.performSpeed();
							Debug.trace("LED speed set to FAST");
							break;
						default:
							;
						}	
					}
				}
				
				// Game Logic
				if (this.bottomLED && this.jumped) {	// check if these two conditions are met
					score += 10;						// increment score 
					System.out.println("You scored! Score = " + score);
					this.bottomLED = false;				// reset flag
					this.jumped = false;				// reset flag
				}
				
			}
			
		} catch (Exception e) { // terminate the program if exception is caught
			e.printStackTrace();
			System.exit(1);
		}
		
	}

}

