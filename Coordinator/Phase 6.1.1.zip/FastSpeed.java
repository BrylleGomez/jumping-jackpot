import java.io.IOException;

public class FastSpeed implements SpeedBehavior {

	public void speed(ProxyLED proxyled)
	{
		try {
			proxyled.send_msg(new msg((byte)(2)));		// send instruction 2 to LED
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
