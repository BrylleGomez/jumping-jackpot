
public interface SpeedBehavior {
	// One type of behavior for the game's Strategy Design Pattern
	
	public void speed(ProxyLED proxyLED);

}
