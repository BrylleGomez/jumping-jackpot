import java.io.IOException;

public class SlowSpeed implements SpeedBehavior {

	public void speed(ProxyLED proxyled)
	{
		try {
			proxyled.send_msg(new msg((byte)(1)));			// send instruction 1 to LED
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
